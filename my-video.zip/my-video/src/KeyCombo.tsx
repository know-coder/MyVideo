import React from "react";
import { Easing, interpolate } from "remotion";
import { KeyBadge } from "./KeyBadge";

export const KeyCombo: React.FC<{
  keys: string[];
  frame: number;
  delay: number;
}> = ({ keys, frame, delay }) => {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
      {keys.map((key, i) => {
        const start = delay + i * 8;
        const scale = interpolate(frame, [start, start + 16], [0.4, 1], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
          easing: Easing.spring({ damping: 12 }),
          output: "perceptual-scale",
        });
        const opacity = interpolate(frame, [start, start + 10], [0, 1], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        });

        return (
          <React.Fragment key={`${key}-${i}`}>
            {i > 0 && (
              <span
                style={{
                  fontSize: 56,
                  color: "#5B6478",
                  fontWeight: 300,
                  opacity,
                }}
              >
                +
              </span>
            )}
            <KeyBadge label={key} scale={scale} opacity={opacity} />
          </React.Fragment>
        );
      })}
    </div>
  );
};