import React from "react";
import {
  AbsoluteFill,
  Easing,
  interpolate,
  Interactive,
  useCurrentFrame,
} from "remotion";
import { WindowsLogo } from "../components/WindowsLogo";

export type OutroSceneProps = {
  durationInFrames: number;
};

export const OutroScene: React.FC<OutroSceneProps> = ({
  durationInFrames,
}) => {
  const frame = useCurrentFrame();
  const FADE = 15;

  const sceneOpacity = interpolate(
    frame,
    [0, FADE, durationInFrames - FADE, durationInFrames],
    [0, 1, 1, 0],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
  );

  const logoOpacity = interpolate(frame, [0, 16], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const logoScale = interpolate(frame, [0, 22], [0.6, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.spring({ damping: 14 }),
    output: "perceptual-scale",
  });

  const titleOpacity = interpolate(frame, [18, 34], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  const subOpacity = interpolate(frame, [32, 48], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  return (
    <AbsoluteFill
      name="OutroScene"
      style={{
        backgroundColor: "#0B0E14",
        opacity: sceneOpacity,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 32,
        fontFamily: "'Segoe UI', system-ui, sans-serif",
      }}
    >
      <Interactive.Div
        name="Logo"
        style={{
          width: 120,
          height: 120,
          borderRadius: 28,
          background: "linear-gradient(135deg, #00A4EF 0%, #0078D4 100%)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          opacity: logoOpacity,
          scale: logoScale,
        }}
      >
        <WindowsLogo size={60} />
      </Interactive.Div>
      <Interactive.Div
        name="Title"
        style={{
          fontSize: 84,
          fontWeight: 700,
          color: "white",
          opacity: titleOpacity,
          textAlign: "center",
        }}
      >
        Selamat Mencoba!
      </Interactive.Div>
      <Interactive.Div
        name="Subtitle"
        style={{
          fontSize: 40,
          color: "#A9B1C3",
          opacity: subOpacity,
          textAlign: "center",
        }}
      >
        Praktikkan shortcut ini di PC Windows-mu sekarang
      </Interactive.Div>
    </AbsoluteFill>
  );
};