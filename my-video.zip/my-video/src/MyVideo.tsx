import React from "react";
import { Series } from "remotion";
import { TitleScene } from "./scenes/TitleScene";
import { ShortcutScene } from "./scenes/ShortcutScene";
import { OutroScene } from "./scenes/OutroScene";
import { shortcuts } from "./data/shortcuts";

export const TITLE_DURATION = 90;
export const SHORTCUT_DURATION = 90;
export const OUTRO_DURATION = 90;
export const TOTAL_DURATION =
  TITLE_DURATION + shortcuts.length * SHORTCUT_DURATION + OUTRO_DURATION;

export const MyVideo: React.FC = () => {
  return (
    <Series>
      <Series.Sequence name="Title" durationInFrames={TITLE_DURATION}>
        <TitleScene durationInFrames={TITLE_DURATION} />
      </Series.Sequence>
      {shortcuts.map((s, i) => (
        <Series.Sequence
          key={s.title}
          name={s.title}
          durationInFrames={SHORTCUT_DURATION}
        >
          <ShortcutScene
            index={i + 1}
            total={shortcuts.length}
            combos={s.combos}
            comboJoiner={s.comboJoiner}
            title={s.title}
            description={s.description}
            durationInFrames={SHORTCUT_DURATION}
          />
        </Series.Sequence>
      ))}
      <Series.Sequence name="Outro" durationInFrames={OUTRO_DURATION}>
        <OutroScene durationInFrames={OUTRO_DURATION} />
      </Series.Sequence>
    </Series>
  );
};