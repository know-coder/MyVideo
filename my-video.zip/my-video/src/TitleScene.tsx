import React from "react";
import {
  AbsoluteFill,
  Easing,
  interpolate,
  Interactive,
  useCurrentFrame,
} from "remotion";
import { WindowsLogo } from "../components/WindowsLogo";

export type TitleSceneProps = {
  durationInFrames: number;
};

export const TitleScene: React.FC<TitleSceneProps> = ({
  durationInFrames,
}) => {
  const frame = useCurrentFrame();
  const FADE = 15;

  const sceneOpacity = interpolate(
    frame,
    [0, FADE, durationInFrames - FADE, durationInFrames],
    [0, 1, 1, 0],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
  );

  const logoOpacity = interpolate(frame, [0, 15], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const logoScale = interpolate(frame, [0, 22], [0.5, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.spring({ damping: 14 }),
    output: "perceptual-scale",
  });

  const titleOpacity = interpolate(frame, [16, 32], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const titleY = interpolate(frame, [16, 32], [24, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.bezier(0.16, 1, 0.3, 1),
  });

  const subOpacity = interpolate(frame, [30, 46], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  return (
    <AbsoluteFill
      name="TitleScene"
      style={{
        backgroundColor: "#0B0E14",
        opacity: sceneOpacity,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 40,
        fontFamily: "'Segoe UI', system-ui, sans-serif",
      }}
    >
      <Interactive.Div
        name="Logo"
        style={{
          width: 160,
          height: 160,
          borderRadius: 36,
          background: "linear-gradient(135deg, #00A4EF 0%, #0078D4 100%)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          scale: logoScale,
          opacity: logoOpacity,
          boxShadow: "0 24px 60px rgba(0, 120, 212, 0.45)",
        }}
      >
        <WindowsLogo size={80} />
      </Interactive.Div>

      <Interactive.Div
        name="Title"
        style={{
          fontSize: 96,
          fontWeight: 700,
          color: "white",
          opacity: titleOpacity,
          translate: `0 ${titleY}px`,
          textAlign: "center",
        }}
      >
        Shortcut Keyboard Windows
      </Interactive.Div>

      <Interactive.Div
        name="Subtitle"
        style={{
          fontSize: 44,
          color: "#A9B1C3",
          opacity: subOpacity,
          textAlign: "center",
        }}
      >
        7 kombinasi tombol untuk kerja lebih cepat
      </Interactive.Div>
    </AbsoluteFill>
  );
};