import "./index.css";
import { Composition, Folder } from "remotion";
import { TitleScene } from "./scenes/TitleScene";
import { ShortcutScene } from "./scenes/ShortcutScene";
import { OutroScene } from "./scenes/OutroScene";
import {
  MyVideo,
  TITLE_DURATION,
  SHORTCUT_DURATION,
  OUTRO_DURATION,
  TOTAL_DURATION,
} from "./MyVideo";
import { shortcuts } from "./data/shortcuts";

const FPS = 30;
const WIDTH = 1920;
const HEIGHT = 1080;

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="WindowsShortcuts"
        component={MyVideo}
        width={WIDTH}
        height={HEIGHT}
        fps={FPS}
        durationInFrames={TOTAL_DURATION}
      />
      <Folder name="WindowsShortcuts-Scenes">
        <Composition
          id="Title"
          component={TitleScene}
          width={WIDTH}
          height={HEIGHT}
          fps={FPS}
          durationInFrames={TITLE_DURATION}
          defaultProps={{ durationInFrames: TITLE_DURATION }}
        />
        {shortcuts.map((s, i) => (
          <Composition
            key={s.title}
            id={`Shortcut-${i + 1}`}
            component={ShortcutScene}
            width={WIDTH}
            height={HEIGHT}
            fps={FPS}
            durationInFrames={SHORTCUT_DURATION}
            defaultProps={{
              index: i + 1,
              total: shortcuts.length,
              combos: s.combos,
              comboJoiner: s.comboJoiner,
              title: s.title,
              description: s.description,
              durationInFrames: SHORTCUT_DURATION,
            }}
          />
        ))}
        <Composition
          id="Outro"
          component={OutroScene}
          width={WIDTH}
          height={HEIGHT}
          fps={FPS}
          durationInFrames={OUTRO_DURATION}
          defaultProps={{ durationInFrames: OUTRO_DURATION }}
        />
      </Folder>
    </>
  );
};
