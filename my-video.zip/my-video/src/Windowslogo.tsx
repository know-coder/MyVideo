import React from "react";

export const WindowsLogo: React.FC<{ size: number }> = ({ size }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
    <rect x="1" y="1" width="10" height="10" fill="white" />
    <rect x="13" y="1" width="10" height="10" fill="white" />
    <rect x="1" y="13" width="10" height="10" fill="white" />
    <rect x="13" y="13" width="10" height="10" fill="white" />
  </svg>
);