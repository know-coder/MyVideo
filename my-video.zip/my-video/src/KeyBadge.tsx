import React from "react";
import { WindowsLogo } from "./WindowsLogo";

export const KeyBadge: React.FC<{
  label: string;
  scale: number;
  opacity: number;
}> = ({ label, scale, opacity }) => {
  const isWin = label.toLowerCase() === "win";

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 14,
        minWidth: 140,
        height: 140,
        padding: "0 32px",
        borderRadius: 24,
        background: isWin
          ? "linear-gradient(135deg, #00A4EF 0%, #0078D4 100%)"
          : "#1B2030",
        border: isWin ? "none" : "2px solid #3A4152",
        boxShadow: "0 18px 40px rgba(0,0,0,0.35)",
        scale,
        opacity,
      }}
    >
      {isWin && <WindowsLogo size={44} />}
      <span
        style={{
          fontFamily: "'Segoe UI', system-ui, sans-serif",
          fontSize: 56,
          fontWeight: 600,
          color: "white",
          lineHeight: 1,
        }}
      >
        {label}
      </span>
    </div>
  );
};