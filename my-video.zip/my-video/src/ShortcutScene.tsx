import React from "react";
import {
  AbsoluteFill,
  Easing,
  interpolate,
  Interactive,
  useCurrentFrame,
} from "remotion";
import { KeyCombo } from "../components/KeyCombo";

export type ShortcutSceneProps = {
  index: number;
  total: number;
  combos: string[][];
  comboJoiner?: string;
  title: string;
  description: string;
  durationInFrames: number;
};

export const ShortcutScene: React.FC<ShortcutSceneProps> = ({
  index,
  total,
  combos,
  comboJoiner,
  title,
  description,
  durationInFrames,
}) => {
  const frame = useCurrentFrame();
  const FADE = 12;

  const sceneOpacity = interpolate(
    frame,
    [0, FADE, durationInFrames - FADE, durationInFrames],
    [0, 1, 1, 0],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
  );

  const eyebrowOpacity = interpolate(frame, [0, 14], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  const titleOpacity = interpolate(frame, [26, 42], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const titleY = interpolate(frame, [26, 42], [30, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.bezier(0.16, 1, 0.3, 1),
  });

  const descOpacity = interpolate(frame, [38, 54], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  return (
    <AbsoluteFill
      name="ShortcutScene"
      style={{
        backgroundColor: "#0B0E14",
        opacity: sceneOpacity,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 56,
        fontFamily: "'Segoe UI', system-ui, sans-serif",
      }}
    >
      <Interactive.Div
        name="Eyebrow"
        style={{
          position: "absolute",
          top: 100,
          fontSize: 36,
          letterSpacing: 4,
          color: "#4FC3F7",
          fontWeight: 600,
          opacity: eyebrowOpacity,
          textTransform: "uppercase",
        }}
      >
        Shortcut {index} dari {total}
      </Interactive.Div>

      <div style={{ display: "flex", alignItems: "center", gap: 40 }}>
        {combos.map((combo, i) => (
          <React.Fragment key={combo.join("-")}>
            {i > 0 && (
              <span style={{ fontSize: 48, color: "#5B6478" }}>
                {comboJoiner ?? "&"}
              </span>
            )}
            <KeyCombo keys={combo} frame={frame} delay={16 + i * 20} />
          </React.Fragment>
        ))}
      </div>

      <Interactive.Div
        name="Title"
        style={{
          fontSize: 92,
          fontWeight: 700,
          color: "white",
          opacity: titleOpacity,
          translate: `0 ${titleY}px`,
          textAlign: "center",
        }}
      >
        {title}
      </Interactive.Div>

      <Interactive.Div
        name="Description"
        style={{
          fontSize: 46,
          color: "#A9B1C3",
          opacity: descOpacity,
          textAlign: "center",
          maxWidth: 1400,
        }}
      >
        {description}
      </Interactive.Div>
    </AbsoluteFill>
  );
};