export type ShortcutData = {
  combos: string[][];
  comboJoiner?: string;
  title: string;
  description: string;
};

export const shortcuts: ShortcutData[] = [
  {
    combos: [["Win", "E"]],
    title: "Buka File Explorer",
    description: "Akses folder dan file tanpa perlu mencari ikonnya di taskbar",
  },
  {
    combos: [["Win", "D"]],
    title: "Tampilkan Desktop",
    description: "Minimize semua jendela yang terbuka dalam sekejap",
  },
  {
    combos: [["Win", "L"]],
    title: "Kunci Layar",
    description: "Amankan PC dengan cepat saat meninggalkan meja",
  },
  {
    combos: [
      ["Ctrl", "C"],
      ["Ctrl", "V"],
    ],
    comboJoiner: "&",
    title: "Copy & Paste",
    description: "Duplikat teks atau file, lalu tempel di mana saja",
  },
  {
    combos: [["Alt", "Tab"]],
    title: "Ganti Aplikasi",
    description: "Beralih dengan cepat antar jendela yang sedang terbuka",
  },
  {
    combos: [["Win", "Shift", "S"]],
    title: "Screenshot Sebagian",
    description: "Tangkap sebagian layar dan langsung tersalin ke clipboard",
  },
  {
    combos: [["Win", "."]],
    title: "Panel Emoji",
    description: "Buka pemilih emoji, simbol, dan GIF secara instan",
  },
];